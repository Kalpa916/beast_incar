#creating a .csv file and writing into it.
f=open("emp.csv",mode="w")
f.write("101,Miller,70000") #file already exists, so it truncates
f.write("\n102,Blake,80000")
f.write("\n103,James,90000")
f.close()       #if file doesnt exist, it creates a new file and writes

f1=open("emp.csv")
print(f1.read())    
f1.close()
