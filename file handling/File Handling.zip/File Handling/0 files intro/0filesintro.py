
File Handling:
All programming languages process data in Ram,but RAM is a
volatile,once execution is finished, the data is removed.

Programming Languages are good for processing
Programming Languages are bad for storage

python programs are processed within ram and after processing
they can be stored in any of the following.
1)Files--->.txt,.csv,.xls,.pdf,.xml,.json
2)Databases-->oracle,mysql,DB2
3)NoSQL--->cassandra,mongoDB,HBase,

python can easily connect with the files and databases to
store and retrieve the data.

The various operations we can perform on a file:
    1.opening a file 
    2.closing a file
    3.Reading data from a file
    4.writing data to a file, etc...
for performing above operations, we have built-in functions.
such as open(),close(),read(),write() etc...







