

f=open("sample.txt","r+")  #r+ mode wont remove the previous data

print(f.read())
f.write(" manager Pune ")
f.close()
