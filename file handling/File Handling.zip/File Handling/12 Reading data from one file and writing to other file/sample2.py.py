f1=open("C:/python630am/str3.py","r")
x=f1.readlines()
f1.close()

f2=open("demo3.txt","w+")
for line in x:
    f2.write(line)
f2.seek(0)
print(f2.read())
f2.close()

'''
f3=open("demo2.txt","r")
print(f3.read())
f3.close()
'''

